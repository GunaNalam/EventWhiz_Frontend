// ImageOverlay.js
import React from 'react';
import './ImageOverlay.css'; // Import the CSS file for styles

const ImageOverlay = ({ imageUrl, textOverlay }) => {
  return (
    <div>Hello</div>
    );

};

export default ImageOverlay;
