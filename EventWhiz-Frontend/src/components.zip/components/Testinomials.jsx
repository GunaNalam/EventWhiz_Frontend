function Testinomials() {
  return <div>Testinomials</div>;
}

export default Testinomials;
